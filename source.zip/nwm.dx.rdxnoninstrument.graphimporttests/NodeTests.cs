﻿using System;
using System.Collections.Generic;
using nwm.dx.rdxnoninstrument.graphimport;
using NUnit.Framework;

namespace nwm.dx.rdxnoninstrument.graphimporttests
{
	[TestFixture]
	public class NodeTests
	{
		[Test]
		[TestCase("WriteTime")]
		[TestCase("_hash")]
		[TestCase("from")]
		[TestCase("_key")]
		public void NodeHashDoesNotChangeWithSpecialKeys(string specialField)
		{
			var node1Properties = new Dictionary<string, object>()
			{
				{"CisCode","1"},
				{"Test","CisCode"},
				{Node.LabelFieldName,"LegalEntity"},
				{specialField, Guid.NewGuid().ToString()},
				{"SourceName", "Grdm" }
			};

			var node2Properties = new Dictionary<string, object>()
			{
				{"CisCode","1"},
				{"Test","CisCode"},
				{Node.LabelFieldName,"LegalEntity"},
				{specialField, Guid.NewGuid().ToString()},
				{"SourceName", "Grdm" }
			};

			var node1 = new Node("1", "LegalEntity", node1Properties);
			var node2 = new Node("1", "LegalEntity", node2Properties);

			Assert.AreEqual(node1.Hash, node2.Hash);
		}

		[Test]
		public void NodeWithSamePropertiesAreEqual()
		{
			var currentTimeStamp = DateTime.Now;

			var node1Properties = new Dictionary<string, object>()
			{
				{"CisCode","1"},
				{Node.KeyFieldName,"CisCode"},
				{Node.LabelFieldName,"LegalEntity"},
				{Node.WriteTimeFieldName, currentTimeStamp},
				{"SourceName", "Grdm" }
			};

			var node2Properties = new Dictionary<string, object>()
			{
				{"CisCode","1"},
				{Node.KeyFieldName,"CisCode"},
				{Node.LabelFieldName,"LegalEntity"},
				{Node.WriteTimeFieldName, currentTimeStamp},
				{"SourceName", "Grdm" }
			};

			var node1 = new Node("1", "LegalEntity", node1Properties);
			var node2 = new Node("1", "LegalEntity", node2Properties);

			Assert.AreEqual(node1, node2);
		}
	}
}
