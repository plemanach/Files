﻿using nwm.dx.rdxnoninstrument.graphimport;
using NUnit.Framework;
using System.Collections.Generic;
using System.IO;

namespace nwm.dx.rdxnoninstrument.graphimporttests
{
    public class GraphMLWriterTests
    {
        [Test]
        public void WriteSimple()
        {
            var graphMLReader = new GraphMLReader("Sample1.xml");

            var expectedNodes = new List<Node>();
            var expectedEdges = new List<Edge>();

            graphMLReader.NodeParsed += (sender, node) => { expectedNodes.Add(node); };
            graphMLReader.EdgeParsed += (sender, edge) => { expectedEdges.Add(edge); };
            graphMLReader.Read();

            var outPutStream = new MemoryStream();
            var streamWriter = new StreamWriter(outPutStream);
            var graphMLWriter = new GraphMLWriter(new GraphObject(expectedNodes, expectedEdges), streamWriter);
            graphMLWriter.Write();

            outPutStream.Position = 0;

            var resultNodes = new List<Node>();
            var resultEdges = new List<Edge>();

            var checkGraphMLReader = new GraphMLReader(outPutStream);
            checkGraphMLReader.NodeParsed += (sender, node) => { resultNodes.Add(node); };
            checkGraphMLReader.EdgeParsed += (sender, edge) => { resultEdges.Add(edge); };
            checkGraphMLReader.Read();

            CollectionAssert.AreEquivalent(resultNodes, resultNodes);
            CollectionAssert.AreEquivalent(resultEdges, resultEdges);
        }

        [Test]
        public void WriteListPropertyTest()
        {
            using (var stream = new MemoryStream())
            using (var streamWriter = new StreamWriter(stream))
            using (var streamReader = new StreamReader(stream))
            {
	            var nodeProperties = new Dictionary<string, object>
	            {
		            {"someProp", "test123"},
                    {"listProp", new List<object> { "item1", "item2", "item3" } }
	            };

                var nodes = new List<Node> { new Node("1", "lbl", nodeProperties) };
                var edges = new List<Edge>();

                var writer = new GraphMLWriter(new GraphObject(nodes, edges), streamWriter);

                writer.Write();

                stream.Position = 0;

                var result = streamReader.ReadToEnd();

                Assert.IsTrue(result.Contains(@"<data key=""listProp"">item1</data>"));
                Assert.IsTrue(result.Contains(@"<data key=""listProp"">item2</data>"));
                Assert.IsTrue(result.Contains(@"<data key=""listProp"">item3</data>"));
            }
        }
    }
}
