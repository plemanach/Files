﻿using System;
using System.Collections.Generic;
using System.IO;
using nwm.dx.rdxnoninstrument.graphimport;
using NUnit.Framework;

namespace nwm.dx.rdxnoninstrument.graphimporttests
{
    [TestFixture]
    public class GraphMLReaderTests
    {
        [Test]
        public void ReadSimple()
        {
            const int nodeExpected = 2;
            const int edgeExpected = 1;

            var graphMLReader = new GraphMLReader("Sample1.xml");

            int nodeCount = 0;
            int edgeCount = 0;

            graphMLReader.NodeParsed += (sender, node) => { nodeCount++; };
            graphMLReader.EdgeParsed += (sender, edge) => { edgeCount++; };

            graphMLReader.Read();

            Assert.AreEqual(nodeExpected, nodeCount);
            Assert.AreEqual(edgeExpected, edgeCount);
        }

        [Test]
        public void ReadPropertyTest()
        {
	        using (var stream = new MemoryStream())
	        using (var streamWriter = new StreamWriter(stream))
	        {
		        var graphMl = "<graphml>" +
			                      "<node id=\"1\">" +
									"<data key=\"someProp\">test123</data>" +
									"<data key=\"someOtherProp\">test345</data>" +
									"<data key=\"labelV\">lbl</data>" +
			                      "</node>" +
		                      "</graphml>";

		        streamWriter.Write(graphMl.AsSpan());
		        streamWriter.Flush();

		        stream.Position = 0;

		        var reader = new GraphMLReader(stream);

		        Node node = null;

		        reader.NodeParsed += (sender, parsedNode) => node = parsedNode;

		        reader.Read();

		        Assert.IsNotNull(node);
		        Assert.IsTrue(node.Attributes.ContainsKey("someProp"));
		        Assert.IsTrue(node.Attributes.ContainsKey("someOtherProp"));

				Assert.AreEqual(2, node.Attributes.Count);
				Assert.AreEqual("test123", node.Attributes["someProp"]);
				Assert.AreEqual("test345", node.Attributes["someOtherProp"]);                
	        }
        }

        [Test]
        public void ReadListPropertyTest()
        {
	        using (var stream = new MemoryStream())
	        using (var streamWriter = new StreamWriter(stream))
	        {
		        var graphMl = "<graphml>" +
								"<node id=\"1\">" +
									"<data key=\"someProp\">test123</data>" +
									"<data key=\"listProp\">item1</data>" +
									"<data key=\"listProp\">item2</data>" +
									"<data key=\"listProp\">item3</data>" +
									"<data key=\"listProp\">item4</data>" +
									"<data key=\"_hash\">49fbffbf34519a1970106ee8089f769d89329280</data>" +
									"<data key=\"labelV\">lbl</data>" +
								"</node>" +
							  "</graphml>";

				streamWriter.Write(graphMl.AsSpan());
				streamWriter.Flush();

				stream.Position = 0;
				
                var reader = new GraphMLReader(stream);

                Node node = null;

                reader.NodeParsed += (sender, parsedNode) => node = parsedNode;

				reader.Read();

				Assert.IsNotNull(node);
				Assert.IsTrue(node.Attributes["listProp"] is List<object>);

				var values = node.Attributes["listProp"].AsList();
				
				Assert.IsNotNull(values);
				Assert.AreEqual(4, values.Count);
                Assert.IsTrue(values.Contains("item1"));
                Assert.IsTrue(values.Contains("item2"));
                Assert.IsTrue(values.Contains("item3"));			
                Assert.IsTrue(values.Contains("item4"));			
	        }
        }
    }
}
