﻿using nwm.dx.rdxnoninstrument.graphimport;
using NUnit.Framework;
using System.Collections.Generic;
using System.IO;
using System;
using System.Threading.Tasks;
using System.Text;

namespace nwm.dx.rdxnoninstrument.graphimporttests
{
    public class GremlinAsyncImporterTests
    {

        [Test]
        public async Task ImportAsync()
        {
            var traversalSource = GraphTraversalFactory.CreateTraversal("192.168.99.100", 30939);
            using (var stream = new MemoryStream())
            using (var streamWriter = new StreamWriter(stream))
            {
                var graphMlBuilder = new StringBuilder("<graphml>");
                int bulkNB = 100;
                for (int i = 0; i < bulkNB; i++)
                {
                    graphMlBuilder.Append($"<node id=\"{i}\">");
                    graphMlBuilder.Append("<data key=\"labelV\">Contact</data>");
                    graphMlBuilder.Append("<data key=\"_label\">Contact</data>");
                    graphMlBuilder.Append($"<data key=\"EntityKey\">tttest{i}</data>");
                    graphMlBuilder.Append("<data key=\"Status\">1</data>");
                    graphMlBuilder.Append("<data key=\"WorkWithNucleusId\">test1</data>");
                    graphMlBuilder.Append($"<data key=\"Name\">{i}</data>");
                    //graphMlBuilder.Append($"<data key=\"_hash\">test{i}</data>");
                    graphMlBuilder.Append("<data key=\"_key\">EntityKey,_hash</data>");
                    graphMlBuilder.Append("</node>");
                }
                /*
                for (int i = 0; i < bulkNB; i++)
                {
                    graphMlBuilder.Append($"<edge id=\"{i}\" source=\"{i}\" target=\"{(i+1 == bulkNB ? (bulkNB-1): (i+1))}\">");
                    graphMlBuilder.Append("<data key=\"from\">1490842800</data>");
                    graphMlBuilder.Append("<data key=\"labelE\" >state</data>");
                    graphMlBuilder.Append("<data key=\"_fromNode\" >Contact</data>");
                    graphMlBuilder.Append($"<data key=\"_fromNodeKey\" >EntityKey</data>");
                    graphMlBuilder.Append($"<data key=\"_toNodeKey\" >EntityKeyBrother</data>");
                    graphMlBuilder.Append($"<data key=\"EntityKey\" >test{i}</data>");
                    graphMlBuilder.Append("<data key=\"_toNode\" >Contact</data>");
                    graphMlBuilder.Append("<data key=\"_key\">EntityKey,_hash</data>");
                    graphMlBuilder.Append("</edge>");
                }*/
                graphMlBuilder.Append("</graphml>");

                streamWriter.Write(graphMlBuilder.ToString().AsSpan());
                streamWriter.Flush();

                stream.Position = 0;

                var reader = new GraphMLReader(stream);
                var memoryStateManager = new MemoryStateManager();
                var gremlinAsyncImporter = new GremlinAsyncImporter(traversalSource, reader, memoryStateManager);
                gremlinAsyncImporter.ImportFinished += (o,e)=> { Console.WriteLine($"ms:{e.TotalInsertionTime}"); };

                try
                {
                   await gremlinAsyncImporter.ImportAsync();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    Assert.Fail();
                }
            }
        }
    }
}
