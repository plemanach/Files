﻿
using System;
using System.Collections.Generic;
using System.Text;

namespace nwm.dx.rdxnoninstrument.graphimport
{
    public static class ExtensionMethods
    {
	    public static IList<object> AsList(this object obj)
	    {
		    if (obj is IList<object> list)
		    {
			    return list;
		    }

            return new List<object>(1) { obj };
	    }
    }
}
