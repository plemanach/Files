﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Gremlin.Net.Process.Traversal;
using Gremlin.Net.Structure;
using nwm.dx.rdxnoninstrument.graphimport.Exceptions;
using nwm.dx.rdxnoninstrument.graphimport.Extensions;
using nwm.dx.utils;
using TaskExtensions = nwm.dx.rdxnoninstrument.graphimport.Extensions.TaskExtensions;

namespace nwm.dx.rdxnoninstrument.graphimport
{
	public class GremlinAsyncImporter
	{
		public event EventHandler<ErrorArgs> Error;
	    public event EventHandler<EdgeArgs> EdgeImported;
	    public event EventHandler<NodeArgs> NodeImported;
	    public event EventHandler<ImportFinishedArgs> ImportFinished;

		private readonly IGraphReader graphReader;
		private readonly IImportStateManager importStateManager;
	    private readonly GraphTraversalSource g;

	    private readonly List<Node> nodes = new List<Node>();
        private readonly List<Edge> edges = new List<Edge>();
        private const int GremlinQueryTimeoutInMs = 30000;

        public GremlinAsyncImporter(
		    GraphTraversalSource traversalSource,
			IGraphReader graphReader,
			IImportStateManager importStateManager)
        {
            this.g = ArgumentValidator.CheckForNullReference(traversalSource, nameof(traversalSource));
            this.graphReader = ArgumentValidator.CheckForNullReference(graphReader, nameof(graphReader));
			this.importStateManager = ArgumentValidator.CheckForNullReference(importStateManager, nameof(importStateManager));

			graphReader.NodeParsed += (sender, node) =>
			{
				try
				{
					nodes.Add(node);
				}
				catch (Exception e)
				{
					importStateManager.WriteStates();
					OnError(new ErrorArgs("Node parsed", e));
				}
			};

			graphReader.EdgeParsed += (sender, edge) =>
			{
				try
				{
					edges.Add(edge);
				}
				catch (Exception e)
				{
					importStateManager.WriteStates();
					OnError(new ErrorArgs("Edge parsed", e));
				}
			};
        }

		public long NodeProcessed => importStateManager.NodeProcessed;

		public long EdgeProcessed => importStateManager.EdgeProcessed;		

		public async Task ImportAsync()
		{
			var sw = new Stopwatch();
			sw.Start();

			nodes.Clear();
			edges.Clear();

			var nodeTasks = new Dictionary<Node, Task<InsertionResult>>();
			var edgeTasks = new Dictionary<Edge, Task<Task<InsertionResult>>>();

			importStateManager.Load();

			graphReader.Read();

         
            var nodeList = nodes.ToList();

            var nodesResult = AddNode2(nodeList);

            foreach (var node in nodeList)
			{
                var internalId = (long)nodesResult[node.Id];
                importStateManager.AddNodeProcessed(node.Label, node.Id, internalId);
				OnNodeImported(new NodeArgs(node, new InsertionResult(internalId, "", 0)));
			}

            var edgeInsertionResult = await AddEdgeAsync(edges);
		
            foreach(var edge in edges)
            {
                importStateManager.AddEdgeProcessed(edge.Label, edge.Id);
                OnEdgeImported(new EdgeArgs(edge, edgeInsertionResult));
            }

            importStateManager.WriteStates();

			sw.Stop();
            ImportFinished?.Invoke(this, new ImportFinishedArgs(NodeProcessed, EdgeProcessed, sw.ElapsedMilliseconds));
        }

		public void SaveState()
		{
			importStateManager.WriteStates();
		}


        private IDictionary<string, object> AddNode2(List<Node> nodes)
        {
            GraphTraversal<Vertex, Vertex> v = g.V();

            List<ITraversal> hasClauses = new List<ITraversal>();
            var query = new StringBuilder("g.V().and(");
            var nodeCount = nodes.Count;
            var globalKeys = nodes.SelectMany(n => n.Keys).Distinct();
       
            foreach (var keyglobalKey in globalKeys)
            {
                List<object> keyValue = new List<object>();
                for (int i = 0; i < nodeCount; i++)
                {
                    var node = nodes[i];
                    var keysHash = node.Keys.ToHashSet();

                    if (keysHash.Contains(keyglobalKey))
                    {
                        keyValue.Add(node.Attributes[keyglobalKey]);
                    }
                }
                var keyValues = keyValue.ToArray();
                hasClauses.Add(__.Has(keyglobalKey, P.Within(keyValues)));
                query.Append($".has('{keyglobalKey}', within([{string.Join(',', keyValues.Select(k => "'" + k + "'" ) )}])),");
            }

            v = v.And(hasClauses.ToArray());

            var nodesById = new Dictionary<string, object>();

            IList<IDictionary<object, object>> nodesFound = v.ValueMap<object, object>(true, globalKeys.ToArray()).ToList();
            for (int i = 0; i < nodeCount; i++)
            {
                var node = nodes[i];
                var keys = node.Keys.ToHashSet();
                var keyCount = node.Keys.Count();
                int keyFoundCount = 0;
               
                foreach (var nodeFoundValue in nodesFound)
                {
                    foreach (var key in keys)
                    {
                        if (nodeFoundValue.ContainsKey(key) && string.Compare((nodeFoundValue[key] as object[]).FirstOrDefault() as string, node.Attributes[key] as string, true) == 0 )
                        {
                            keyFoundCount++;
                        }
                    }

                    if (keyCount == keyFoundCount)
                    {
                        
                        if(nodeFoundValue.ContainsKey(T.Id))
                        {
                            nodesById.Add(node.Id, nodeFoundValue[Gremlin.Net.Process.Traversal.T.Id] as long?);
                            break;
                        }
                      
                    }
                }
            }

            GraphTraversal<Gremlin.Net.Structure.Vertex, Gremlin.Net.Structure.Vertex> nodeInsert = null;
            var addBuilder = new StringBuilder();
            for (int i = 0; i < nodeCount; i++)
            {
                var node = nodes[i];
                if (!nodesById.ContainsKey(node.Id))
                {
                  
                    if (nodeInsert == null)
                    {
                        nodeInsert = g.AddV(node.Label).As(node.Id);
                        addBuilder.Append($"g.AddV('{node.Label}')");
                    }
                    else
                    {
                        nodeInsert = nodeInsert.AddV(node.Label).As(node.Id);
                        addBuilder.Append($"AddV('{node.Label}')");
                    }

                    foreach (var property in node.Attributes)
                    {
                        foreach (var value in property.Value.AsList())
                        {
                            nodeInsert = nodeInsert.Property(property.Key, value);
                            addBuilder.Append($".property('{property.Key}', '{value}')");
                        }
                    }
                }
            }

            if (nodeInsert != null)
            {
                IDictionary<string, Vertex> res;
                   
                if (nodeCount == 1)
                {
                    res = new Dictionary<string, Vertex>() { { nodes.First().Id, nodeInsert.Select<Vertex>(nodes.First().Id).Next() } };
                }
                else if (nodeCount == 2)
                {
                    res = nodeInsert.Select<Vertex>(nodes.First().Id, nodes.Skip(1).FirstOrDefault()?.Id).Next();
                }
                else
                {
                    res = nodeInsert.Select<Vertex>(nodes.First().Id, nodes.Skip(1).FirstOrDefault()?.Id, nodes.Skip(2).Select(n => n.Id).ToArray()).Next();
                }

                foreach (var nodeInserted in res)
                {
                    if (!nodesById.ContainsKey(nodeInserted.Key))
                    {
                        nodesById.Add(nodeInserted.Key, nodeInserted.Value.Id);
                    }
                }
            }

            return nodesById;
        }


        private IDictionary<string, object> AddNode(List<Node> nodes)
        {
            GraphTraversal<Vertex, Vertex> v = g.V();
            var query = new StringBuilder("g.V()");

            var nodeCount = nodes.Count;

            for (int i = 0; i < nodeCount; i++)
            {
                var node = nodes[i];
                var keys = node.Keys.ToList();

                if (keys.Any())
                {
                    foreach (var key in keys)
                    {
                        v = v.Has(key, node.Attributes[key]);
                        query.Append($".has({key}, '{node.Attributes[key]}')");
                    }

                    v = v.Has(Node.LabelFieldName, node.Label).Limit<Vertex>(1);
                    query.Append($".has('{Node.LabelFieldName}', '{node.Label}').limit(1)");

                    var nodeToAdd = __.AddV(node.Label);
                    var addBuilder = new StringBuilder($"__.addV('{node.Label}')");

                    foreach (var property in node.Attributes)
                    {
                        foreach (var value in property.Value.AsList())
                        {
                            nodeToAdd = nodeToAdd.Property(property.Key, value);
                            addBuilder.Append($".property('{property.Key}', '{property.Value}')");
                        }
                    }

                    var unfold = __.Unfold<Vertex>();
                    var unfoldBuilder = new StringBuilder("unfold()");
                    foreach (var value in node.AltKeys)
                    {
                        unfold = unfold.Property(Node.AltKeyFieldName, value);
                        unfoldBuilder.Append($".property('{Node.AltKeyFieldName}', '{value}')");
                    }

                    v = v.Fold().Coalesce<Vertex>(unfold, nodeToAdd);
                    query.Append($".fold().coalesce({unfoldBuilder}, {addBuilder})");
                }
                else
                {
                    v = (node.Label == null) ? g.AddV() : g.AddV(node.Label);

                    foreach (var property in node.Attributes)
                    {
                        foreach (var value in property.Value.AsList())
                        {
                            v = v.Property(property.Key, value);
                        }
                    }
                }

                if (i < (nodeCount - 1))
                {
                    v = v.Id().Store(node.Id).V();
                }else
                {
                    if (nodeCount == 1)
                    {
                        return new Dictionary<string, object>() { { nodes.First().Id, v.Select<Vertex>(node.Id).Next()}};
                    }
                    else if (nodeCount == 2)
                    {
                        IDictionary<string,object> res =  v.Id().Store(node.Id).Select<object>(nodes.First().Id, node.Id).Next();

                        return res;
                    }else
                    {
                        return v.Id().Store(node.Id).Select<object>(nodes.First().Id, nodes.Skip(1).FirstOrDefault()?.Id, nodes.Skip(2).Select(n => n.Id).ToArray()).Next();
                    }
                }
            }
            return null;
        }


        private async Task<InsertionResult> AddEdgeAsync(List<Edge> edges)
        {
            if (!edges.Any())
            {
                return new InsertionResult(0, "", 0);
            }

            var edgeCount = edges.Count;
            var v = g.E();
            var traversals = new List<ITraversal>();
            var query = new StringBuilder($"g.E().or(");

            for (int i = 0; i < edgeCount; i++)
            {
                var edge = edges[i];
                var internalFromId = importStateManager.GetInternalNodeId(edge.FromLabel, edge.From);
                if (internalFromId == 0)
                {
                    var insertionResult = await InsertNodeAsync(new Node(edge.From, edge.FromLabel, null));
                    importStateManager.AddNodeProcessed(edge.FromLabel, edge.From, insertionResult.InternalId);
                    internalFromId = importStateManager.GetInternalNodeId(edge.FromLabel, edge.From);
                }

                var internalToId = importStateManager.GetInternalNodeId(edge.ToLabel, edge.To);
                if (internalToId == 0)
                {
                    var nodeProperties = new Dictionary<string, object>()
                    {
                        {edge.ToKey, edge.ToKeyValue },
                        {Node.KeyFieldName, edge.ToKey },
                        {Node.LabelFieldName, edge.ToLabel }
                    };

                    if (edge.Properties.ContainsKey(Node.SourceFieldName))
                    {
                        nodeProperties.Add(Node.SourceFieldName, edge.SourceName);
                    }

                    var insertionResult = await InsertNodeAsync(new Node(edge.To, edge.ToLabel, nodeProperties));
                    importStateManager.AddNodeProcessed(edge.ToLabel, edge.To, insertionResult.InternalId);
                    internalToId = importStateManager.GetInternalNodeId(edge.ToLabel, edge.To);
                }

                var keys = edge.Keys.ToList();
                var edgeV = __.HasLabel(edge.Label);
                query.Append($"__.hasLabel('{edge.Label}')");
                if (keys.Any())
                {
                    foreach (var key in keys)
                    {
                        switch (key.Type)
                        {
                            case EdgeKeyTypeEnum.StrictEqual:
                            {
                                edgeV = edgeV.Has(key.Value, edge.Properties[key.Value]);
                                query.Append($".has('{key.Value}', '{edge.Properties[key.Value]}')");
                                break;
                            }
                            case EdgeKeyTypeEnum.Temporal:
                            {
                                edgeV = edgeV.Has(key.Value, P.Lte(long.Parse(edge.Properties[key.Value].ToString()))).Order().By(key.Value, Order.Decr).Limit<object>(1);
                                query.Append($".has('{key.Value}', lte({edge.Properties[key.Value]})).order().by('{key.Value}', decr).limit(1)");
                                break;
                            }
                        }
                    }
                    edgeV = edgeV.As(edge.Id);
                    query.Append($"as('{edge.Id}'),");
                    traversals.Add(edgeV);
                }
            }

            v = v.Or(traversals.ToArray());
            query.Append(")");
            IDictionary<string, object> edgeLookup = null;

            if (edgeCount > 0)
            {
                if (edgeCount == 1)
                {
                    edgeLookup = new Dictionary<string, object>() {{ edges.FirstOrDefault().Id, v.Select<object>(edges.FirstOrDefault().Id).Next() }};
                    query.Append($".select('{edges.FirstOrDefault().Id}')");
                }
                else if (edgeCount == 2)
                {
                    edgeLookup = v.Select<object>(edges.First().Id, edges.Skip(1).First().Id).Next();
                    query.Append($".select('{edges.First().Id}', '{edges.Skip(1).First().Id}')");
                }
                else
                {
                    edgeLookup = v.Select<object>(edges.First().Id, edges.Skip(1).FirstOrDefault()?.Id, edges.Skip(2).Select(n => n.Id).ToArray()).Next();
                    query.Append($".select('{edges.First().Id}', '{edges.Skip(1).First().Id}', {string.Join(',', edges.Skip(2).Select(n => n.Id).ToArray())}");
                }
            }

            if (edgeLookup == null)
            {
                edgeLookup = new Dictionary<string, object>();
            }

            GraphTraversal<Gremlin.Net.Structure.Edge, Gremlin.Net.Structure.Edge> edgeInsert = null;
            var addBuilder = new StringBuilder(); 
            for (int i = 0; i < edgeCount; i++)
            {
                var edge = edges[i];
                if (!edgeLookup.ContainsKey(edge.Id))
                {
                    var internalFromId = importStateManager.GetInternalNodeId(edge.FromLabel, edge.From);
                    var internalToId = importStateManager.GetInternalNodeId(edge.ToLabel, edge.To);

                    if (edgeInsert == null)
                    {
                        edgeInsert = g.AddE(edge.Label).From(__.V(internalFromId)).To(__.V(internalToId));
                        addBuilder.Append($"g.AddE('{edge.Label}').from(__.V({internalFromId})).to((__.V({internalToId}))");
                    }
                    else
                    {
                        edgeInsert = edgeInsert.AddE(edge.Label).From(__.V(internalFromId)).To(__.V(internalToId));
                        addBuilder.Append($"AddE('{edge.Label}').from(__.V({internalFromId})).to((__.V({internalToId}))");
                    }

                    foreach (var property in edge.Attributes)
                    {
                        foreach (var value in property.Value.AsList())
                        {
                            edgeInsert = edgeInsert.Property(property.Key, value);
                            addBuilder.Append($".property('{property.Key}', '{value}')");
                        }
                    }
                }
            }

            if (edgeInsert != null)
            {
                var res = edgeInsert.ToList();
            }
            return new InsertionResult(0, addBuilder.ToString(), 0);
        }

        private Task<InsertionResult> InsertNodeAsync(Node node)
		{
			var v = g.V();
			var query = new StringBuilder("g.V()");

            var keys = node.Keys.ToList();

            if (keys.Any())
            {
                foreach (var key in keys)
                {
                    v = v.Has(key, node.Attributes[key]);
                    query.Append($".has('{key}', '{node.Attributes[key]}')");
                }

                v = v.Has(Node.LabelFieldName, node.Label).Limit<Vertex>(1);
                query.Append($".has('{Node.LabelFieldName}', '{node.Label}').limit(1)");

				var nodeToAdd = __.AddV(node.Label);
				var addBuilder = new StringBuilder($"__.addV('{node.Label}')");

                foreach (var property in node.Attributes)
                {
                    foreach (var value in property.Value.AsList())
                    {
                        nodeToAdd = nodeToAdd.Property(property.Key, value);
                        addBuilder.Append($".property('{property.Key}', '{property.Value}')");
                    }
                }

                var unfold = __.Unfold<Vertex>();
				var unfoldBuilder = new StringBuilder("unfold()");
                foreach (var value in node.AltKeys)
                {
                    unfold = unfold.Property(Node.AltKeyFieldName, value);
                    unfoldBuilder.Append($".property('{Node.AltKeyFieldName}', '{value}')");
                }

                v = v.Fold().Coalesce<Vertex>(unfold, nodeToAdd);
                query.Append($".fold().coalesce({unfoldBuilder}, {addBuilder})");
            }
            else
            {
                v = (node.Label == null) ? g.AddV() : g.AddV(node.Label);

                foreach (var property in node.Attributes)
                {
                    foreach (var value in property.Value.AsList())
                    {
                        v = v.Property(property.Key, value);
                    }
                }
            }

            var sw = new Stopwatch();
            sw.Start();

            return v.Id().Promise(a =>
            {
				sw.Stop();
	            return new InsertionResult((long) a.Next(), query.ToString(), sw.ElapsedMilliseconds);
            });
        }

		private async Task<Task<InsertionResult>> InsertEdgeAsync(Edge edge)
		{
			var internalFromId = importStateManager.GetInternalNodeId(edge.FromLabel, edge.From);
            if (internalFromId == 0)
            {
                var insertionResult = await InsertNodeAsync(new Node(edge.From, edge.FromLabel, null));
				importStateManager.AddNodeProcessed(edge.FromLabel, edge.From, insertionResult.InternalId);
                internalFromId = importStateManager.GetInternalNodeId(edge.FromLabel, edge.From);
            }

            var internalToId = importStateManager.GetInternalNodeId(edge.ToLabel, edge.To);
            if (internalToId == 0)
            {
                var nodeProperties = new Dictionary<string, object>()
                {
                    {edge.ToKey, edge.ToKeyValue },
                    {Node.KeyFieldName, edge.ToKey },
                    {Node.LabelFieldName, edge.ToLabel }
                };

                if (edge.Properties.ContainsKey(Node.SourceFieldName))
                {
                    nodeProperties.Add(Node.SourceFieldName, edge.SourceName);
                }

                var insertionResult = await InsertNodeAsync(new Node(edge.To, edge.ToLabel, nodeProperties));
				importStateManager.AddNodeProcessed(edge.ToLabel, edge.To, insertionResult.InternalId);
                internalToId = importStateManager.GetInternalNodeId(edge.ToLabel, edge.To);
            }

            var keys = edge.Keys.ToList();

			var v = g.E().HasLabel(edge.Label);
			var query = new StringBuilder($"g.E().hasLabel('{edge.Label}')");

            if (keys.Any())
            {
                foreach (var key in keys)
                {
                    switch (key.Type)
                    {
                        case EdgeKeyTypeEnum.StrictEqual:
                            {
                                v = v.Has(key.Value, edge.Properties[key.Value]);
                                query.Append($".has('{key.Value}', '{edge.Properties[key.Value]}')");
                                break;
                            }
                        case EdgeKeyTypeEnum.Temporal:
                            {
                                v = v.Has(key.Value, P.Lte(long.Parse(edge.Properties[key.Value].ToString()))).Order().By(key.Value, Order.Decr).Limit<Gremlin.Net.Structure.Edge>(1);
                                query.Append($".has('{key.Value}', lte({edge.Properties[key.Value]})).order().by('{key.Value}', decr).limit(1)");
								break;
                            }
                    }
                }
                query.Append("");
            }
            
            var edgeToBeAdded = __.V(internalFromId).As("a").V(internalToId).As("b").AddE(edge.Label).From("a").To("b");
			var addBuilder = new StringBuilder($"__.V({internalFromId}).as('a').V({internalToId}).as('b').addE('{edge.Label}').from('a').to('b')");

            foreach (var property in edge.Attributes)
            {
                foreach (var value in property.Value.AsList())
                {
                    edgeToBeAdded = edgeToBeAdded.Property(property.Key, value);
                    addBuilder.Append($".property('{property.Key}', '{value}')");
                }
            }

            v = v.Fold().Coalesce<Gremlin.Net.Structure.Edge>(__.Unfold<Gremlin.Net.Structure.Edge>(), edgeToBeAdded);
            query.Append($".fold().coalesce(unfold(), {addBuilder})");

            var sw = new Stopwatch();
            sw.Start();

            return v.Id().Promise(x =>
            {
	            x.Next();
				sw.Stop();

				return new InsertionResult(0, query.ToString(), sw.ElapsedMilliseconds);
            });
        }

		private void OnError(ErrorArgs errorArgs)
		{
			Error?.Invoke(this, errorArgs);
		}

	    protected virtual void OnEdgeImported(EdgeArgs e)
	    {			
	        EdgeImported?.Invoke(this, e);
	    }

	    protected virtual void OnNodeImported(NodeArgs e)
	    {
	        NodeImported?.Invoke(this, e);
	    }
	}
}
