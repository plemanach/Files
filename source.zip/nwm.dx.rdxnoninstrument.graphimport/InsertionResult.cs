﻿namespace nwm.dx.rdxnoninstrument.graphimport
{
    public class InsertionResult
    {
        public InsertionResult(long internalId, string query, long insertionTimeInMs)
        {
            InternalId = internalId;
            Query = query;
            InsertionTimeInMs = insertionTimeInMs;
        }

        public long InternalId { get; }

        public string Query { get; }

        public long InsertionTimeInMs { get; }
    }
}
