﻿namespace nwm.dx.rdxnoninstrument.graphimport
{
	public static class KeyOperationMode
	{
		public const string OrOperation = "or";

		public const string AndOperation = "and";
	}
}
