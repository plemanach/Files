﻿using System;

namespace nwm.dx.rdxnoninstrument.graphimport
{
    public class ImportFinishedArgs : EventArgs
    {
	    public long NodesProcessed { get; }
	    public long EdgesProcessed { get; }
	    public long ItemsProcessed { get; }
        public long TotalInsertionTime { get; }

	    public ImportFinishedArgs(long nodesProcessed, long edgesProcessed, long totalInsertionTime)
	    {
		    NodesProcessed = nodesProcessed;
		    EdgesProcessed = edgesProcessed;
		    ItemsProcessed = nodesProcessed + edgesProcessed;
		    TotalInsertionTime = totalInsertionTime;
	    }
    }
}
