﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;
using nwm.dx.utils;

namespace nwm.dx.rdxnoninstrument.graphimport
{
    public class ImportStateManager : IImportStateManager
    {
        public const string NodeFileName = "nodestate";
        public const string EdgeFileName = "edgestate";
        public const int WriteFileCount = 10000000;

        public event EventHandler<string> Loading;
        public event EventHandler<string> Loaded;
        private readonly object fileLock = new object();

        private const string Separator = "¬";
        
        private readonly Dictionary<string, long> graphMLIdToInternalId = new Dictionary<string, long>();
        private readonly HashSet<string> edgeProcessed = new HashSet<string>();
        private readonly HashSet<string> edgeFailed = new HashSet<string>();

        public long NodeProcessed => graphMLIdToInternalId.Count;
        public long EdgeProcessed => edgeProcessed.Count;

        public void AddEdgeProcessed(string label, string id)
        {
            ArgumentValidator.CheckForNullOrEmptyString(label, nameof(label));
            ArgumentValidator.CheckForNullOrEmptyString(id, nameof(id));

            edgeProcessed.Add($"{label}{Separator}{id}");

            if (edgeProcessed.Count % 10000000 == 0)
            {
                WriteStateEdge();
            }
        }

        public void AddNodeProcessed(string label, string id, long janusNodeId)
        {
            ArgumentValidator.CheckForNullOrEmptyString(label, nameof(label));
            ArgumentValidator.CheckForNullOrEmptyString(id, nameof(id));

            var key = $"{label}{Separator}{id}";
            if (!graphMLIdToInternalId.ContainsKey(key))
            {
                graphMLIdToInternalId.Add(key, janusNodeId);
            }
        }

        public long GetInternalNodeId(string label, string id)
        {
            ArgumentValidator.CheckForNullOrEmptyString(label, nameof(label));
            ArgumentValidator.CheckForNullOrEmptyString(id, nameof(id));

            long internalNodeId = 0;

            if (id != null)
            {
                var key = $"{label}{Separator}{id}";
                graphMLIdToInternalId.TryGetValue(key, out internalNodeId);
            }

            return internalNodeId;
        }

        public void AddEdgeFailed(string label, string id)
        {
            ArgumentValidator.CheckForNullOrEmptyString(label, nameof(label));
            ArgumentValidator.CheckForNullOrEmptyString(id, nameof(id));

            edgeFailed.Add($"{label}{Separator}{id}");
        }

        public void Load()
        {
            LoadNodeState();
            LoadEdgeState();
        }

        public void WriteEdgeFailed()
        {
            lock (fileLock)
            {
                string json = JsonConvert.SerializeObject(edgeFailed);
                File.WriteAllText("edgefailled", json);
            }
        }

        public void LoadNodeState()
        {
            lock (fileLock)
            {
                if (File.Exists($"{NodeFileName}1"))
                {
                    int partId = 1;
                    while (File.Exists($"{NodeFileName}{partId}"))
                    {
                        OnLoading($"{NodeFileName}{partId}");

                        var mapString = File.ReadAllText($"{NodeFileName}{partId}");
                        var mapPartIds =
                            JsonConvert.DeserializeObject<Dictionary<string, long>>(mapString);

                        foreach (var ids in mapPartIds)
                        {
                            if (!graphMLIdToInternalId.ContainsKey(ids.Key))
                            {
                                graphMLIdToInternalId.Add(ids.Key, ids.Value);
                            }
                        }

                        partId++;
                    }
                }

                OnLoaded($"loaded nodes:{graphMLIdToInternalId.Count}");
            }
        }

        public void LoadEdgeState()
        {
            lock (fileLock)
            {
                if (File.Exists($"{EdgeFileName}1"))
                {
                    int partId = 1;
                    while (File.Exists($"{EdgeFileName}{partId}"))
                    {
                        OnLoading($"{EdgeFileName}{partId}");

                        var mapString = File.ReadAllText($"{EdgeFileName}{partId}");
                        var mapPartIds = JsonConvert.DeserializeObject<HashSet<string>>(mapString);

                        foreach (var id in mapPartIds)
                        {
                            if (!edgeProcessed.Contains(id))
                            {
                                edgeProcessed.Add(id);
                            }
                        }

                        partId++;
                    }
                }

                OnLoaded($"loaded edges:{edgeProcessed.Count}");
            }
        }

        public void WriteState()
        {
            lock (fileLock)
            {
                if (graphMLIdToInternalId.Count > 0)
                {
                    var mapIdPart = new Dictionary<string, long>();
                    int partNumber = 1;
                    foreach (var ids in graphMLIdToInternalId.ToList())
                    {
                        mapIdPart.Add(ids.Key, ids.Value);

                        if ((mapIdPart.Count % WriteFileCount) == 0)
                        {
                            var filePathLocal = $"{NodeFileName}{partNumber}";
                            Console.WriteLine(filePathLocal);

                            string json = JsonConvert.SerializeObject(mapIdPart);
                            File.WriteAllText(filePathLocal, json);
                            mapIdPart.Clear();
                            partNumber++;
                        }
                    }

                    if (mapIdPart.Any())
                    {
                        var filePathLocal = $"{NodeFileName}{partNumber}";
                        string json = JsonConvert.SerializeObject(mapIdPart);
                        File.WriteAllText(filePathLocal, json);
                    }
                }
            }
        }

        public void WriteStateEdge()
        {
            lock (fileLock)
            {
                if (edgeProcessed.Any())
                {
                    var mapIdPart = new HashSet<string>();
                    int partNumber = 1;
                    foreach (var id in edgeProcessed.ToList())
                    {
                        mapIdPart.Add(id);

                        if ((mapIdPart.Count % WriteFileCount) == 0)
                        {
                            string json = JsonConvert.SerializeObject(mapIdPart);

                            var filePathLocal = $"{EdgeFileName}{partNumber}";
                            File.WriteAllText(filePathLocal, json);
                            mapIdPart.Clear();
                            partNumber++;
                        }
                    }

                    var filePath = $"{EdgeFileName}{partNumber}";
                    Console.WriteLine(filePath);
                    if (mapIdPart.Any())
                    {
                        string json = JsonConvert.SerializeObject(mapIdPart);
                        File.WriteAllText(filePath, json);
                    }
                }
            }
        }

        public void WriteStates()
        {
            lock (fileLock)
            {
                WriteState();
                WriteStateEdge();
            }
        }

        private void OnLoading(string filename)
        {
            Loading?.Invoke(this, filename);
        }

        private void OnLoaded(string debug)
        {
            Loaded?.Invoke(this, debug);
        }
    }
}
