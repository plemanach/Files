﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using nwm.dx.utils;

namespace nwm.dx.rdxnoninstrument.graphimport
{
	public class Node : IEquatable<Node>
	{
		private readonly string id;
		private readonly string label;
		private readonly IDictionary<string, object> properties;

		public const string KeyFieldName = "_key";
		public const string RuleSetIdFieldName = "_ruleSetId";
		public const string KeyFieldOperatorationModeName = "_keytype";
		public const string AltKeyFieldName = "_altkeys";
		public const string HashFieldName = "_hash";
		public const string FromFieldName = "from";
		public const string LabelFieldName = "_label";
		public const string WriteTimeFieldName = "WriteTime";
		public const string SourceFieldName = "SourceName";

		public bool Equals(Node other)
		{
			if (ReferenceEquals(null, other)) return false;
			if (ReferenceEquals(this, other)) return true;
			return string.Equals(id, other.id, StringComparison.OrdinalIgnoreCase)
						 && string.Equals(label, other.label, StringComparison.OrdinalIgnoreCase)
						 && DictionaryComparer.Equals(Properties, other.Properties);
		}

		public override bool Equals(object obj)
		{
			if (ReferenceEquals(null, obj)) return false;
			if (ReferenceEquals(this, obj)) return true;
			if (obj.GetType() != this.GetType()) return false;
			return Equals((Node)obj);
		}

		public override int GetHashCode()
		{
			unchecked
			{
				var hashCode = (id != null ? StringComparer.OrdinalIgnoreCase.GetHashCode(id) : 0);
				hashCode = (hashCode * 397) ^ (label != null ? StringComparer.OrdinalIgnoreCase.GetHashCode(label) : 0);
				return hashCode;
			}
		}

		public Node(string id, string label, IDictionary<string, object> properties)
		{
			this.id = id;
			this.label = label;
			this.properties = properties ?? new Dictionary<string, object>();
		}

		public IDictionary<string, object> Properties
		{
			get
			{
				if (!properties.ContainsKey(HashFieldName))
				{
					properties.Add(HashFieldName, Hash);
				}
				return properties;
			}
		}

		public string Label => label;
		public string Id => id;

		public string KeyFieldOperatorationMode
		{
			get
			{
				bool keyfound = Properties.TryGetValue(KeyFieldOperatorationModeName, out var valueObject);

				if (keyfound)
				{
					return valueObject as string;
				}

				return KeyOperationMode.AndOperation;
			}
		}

		public IEnumerable<object> AltKeys
		{
			get
			{
				bool keyfound = Attributes.TryGetValue(AltKeyFieldName, out var valueObject);

				if (keyfound)
				{
					return valueObject.AsList();
				}
				return Enumerable.Empty<string>();
			}
		}

		public IEnumerable<string> Keys
		{
			get
			{
				bool keyfound = Properties.TryGetValue(KeyFieldName, out var valueObject);

				if (keyfound)
				{
					if (valueObject is string value)
					{
						return value.Split(',');
					}
				}
				return Enumerable.Empty<string>();
			}
		}

		public string Hash
		{
			get
			{
				var concatValues = new StringBuilder();
				foreach (var keyValue in properties.ToList().OrderBy(k => k.Key))
				{
					if (!SpecialKeys.Contains(keyValue.Key))
					{
						foreach (var value in keyValue.Value.AsList())
						{
							concatValues.Append(value);
						}
					}
				}
				//hash all the values to check for unicity
				return HashUtils.Sha1Hash(concatValues.ToString());
			}
		}

		public Dictionary<string, object> Attributes
		{
			get
			{
				return properties.ToDictionary(kv => kv.Key, kv => kv.Value);
			}
		}

		public string SourceName
		{
			get
			{
				properties.TryGetValue(Node.SourceFieldName, out var sourceName);
				return sourceName as string;
			}
		}

		public override string ToString()
		{
			return JsonConvert.SerializeObject(this);
		}

		private IEnumerable<string> SpecialKeys
		{
			get
			{
				yield return FromFieldName;
				yield return HashFieldName;
				yield return KeyFieldName;
				yield return WriteTimeFieldName;
				yield return AltKeyFieldName;
			}
		}
	}
}
