﻿using System;

namespace nwm.dx.rdxnoninstrument.graphimport
{
    public class ErrorArgs : EventArgs
    {
        public string action;
        public Exception ex;

        public ErrorArgs(string action, Exception ex)
        {
            this.action = action;
            this.ex = ex;
        }
    }
}
