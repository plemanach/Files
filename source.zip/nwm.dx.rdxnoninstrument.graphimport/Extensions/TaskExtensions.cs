﻿using nwm.dx.rdxnoninstrument.graphimport.Exceptions;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace nwm.dx.rdxnoninstrument.graphimport.Extensions
{
    public class TaskExtensions
    {
        public static async Task WhenAll(IEnumerable<Task> tasks, int millisecondsTimeOut, CancellationToken cancellationToken, string message)
        {
            Task timeoutTask = Task.Delay(millisecondsTimeOut);
            Task cancellationMonitorTask = Task.Delay(-1, cancellationToken);
            
            Task completedTask = await Task.WhenAny(
                Task.WhenAll(tasks),
                timeoutTask,
                cancellationMonitorTask
            );

            if (completedTask == timeoutTask)
            {
                throw new GraphImportTimeoutException(message);
            }
            if (completedTask == cancellationMonitorTask)
            {
                throw new OperationCanceledException();
            }
            await completedTask;
        }
    }
}
