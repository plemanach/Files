﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml;

namespace nwm.dx.rdxnoninstrument.graphimport
{
    public class GraphMLReader : IGraphReader
    {
        private XmlTextReader reader;

        public event EventHandler<Node> NodeParsed;
        public event EventHandler<Edge> EdgeParsed;

        public GraphMLReader(string uri)
        {
            reader = new XmlTextReader(uri);
            reader.WhitespaceHandling = WhitespaceHandling.None;
        }

        public GraphMLReader(Stream stream)
        {
            reader = new XmlTextReader(stream);
            reader.WhitespaceHandling = WhitespaceHandling.None;
        }

        public void Read()
        {
            reader.MoveToContent();
            bool found = reader.ReadToDescendant("node");

            while (!reader.EOF)
            {
                ParseNodeAndEdge();
            }
        }

        private void ParseNodeAndEdge()
        {
            var elementName = reader.LocalName;

            if (elementName == "node" || elementName == "edge")
            {
                var stringNode = reader.ReadOuterXml();

                var nodeoregde = new XmlDocument();
                nodeoregde.LoadXml(stringNode);

                string label = null;
                string id = null;
                string from = null;
                string to = null;
                bool isEdge = false;
                var properties = new Dictionary<string, object>();

                foreach (var nodeoregdeChildNode in nodeoregde.ChildNodes)
                {
                    var nodeOrdEdge = nodeoregdeChildNode as XmlNode;

                    if (nodeOrdEdge.Attributes["id"] != null && nodeOrdEdge.Attributes["id"].Value != null)
                    {
                        id = nodeOrdEdge.Attributes["id"].Value;
                    }
                    else
                    {
                        continue;
                    }

                    if (elementName == "edge")
                    {
                        if (nodeOrdEdge.Attributes["source"] != null &&
                            nodeOrdEdge.Attributes["source"].Value != null)
                        {
                            from = nodeOrdEdge.Attributes["source"].Value;
                        }

                        if (nodeOrdEdge.Attributes["target"] != null &&
                            nodeOrdEdge.Attributes["target"].Value != null)
                        {
                            to = nodeOrdEdge.Attributes["target"].Value;
                        }
                    }

                    if (nodeOrdEdge != null)
                    {
                        foreach (var data in (nodeoregdeChildNode as XmlNode).ChildNodes)
                        {
	                        if (data is XmlNode nodeData && nodeData.Attributes != null)
                            {
	                            var propertyKey = nodeData.Attributes["key"]?.Value;

                                if (propertyKey != null && (propertyKey == "labelV" ||  propertyKey == "labelE"))
                                {
                                    label = nodeData.InnerXml;

                                    if (propertyKey == "labelE")
                                    {
                                        isEdge = true;
                                    }
                                }
                                else if(propertyKey != null)
                                {	                                
                                    if (properties.ContainsKey(propertyKey))
                                    {
	                                    if (properties[propertyKey] is List<object> list)
	                                    {
		                                    list.Add(nodeData.InnerText);
	                                    }
	                                    else
	                                    {
		                                    properties[propertyKey] = new List<object> { properties[propertyKey], nodeData.InnerXml };
	                                    }                                        
                                    }
                                    else
                                    {
	                                    properties.Add(propertyKey, nodeData.InnerXml);
                                    }
                                }
                            }
                        }

                        if (!isEdge)
                        {
                            OnNodeParsed(new Node(id, label, properties));
                        }
                        else
                        {
                            OnEdgeParsed(new Edge(id, from, to, label, properties));
                        }
                    }
                }
            }
            else
            {
                reader.Read();
            }
        }

        private void OnNodeParsed(Node node)
        {
            NodeParsed?.Invoke(this, node);
        }

        private void OnEdgeParsed(Edge edge)
        {
            EdgeParsed?.Invoke(this, edge);
        }
    }
}
