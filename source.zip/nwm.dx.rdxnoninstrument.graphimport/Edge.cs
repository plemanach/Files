﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using nwm.dx.utils;

namespace nwm.dx.rdxnoninstrument.graphimport
{

    public enum EdgeKeyTypeEnum
    {
        StrictEqual,
        Temporal
    }

    public class EdgeKey
    {
        public EdgeKey(string value, EdgeKeyTypeEnum edgeKeyType)
        {
            Value = value;
            Type = edgeKeyType;
        }

        public string Value { get; private set; }

        public EdgeKeyTypeEnum Type { get; private set; }
    }


    public class Edge : IEquatable<Edge>
    {
		private string id;
		private string label;
		private string from;
		private string to;
		private IDictionary<string, object> properties;		        

        public Edge(string id, string from, string to, string label, IDictionary<string, object> properties)
        {
            this.id = id;
            this.from = from;
            this.to = to;
            this.properties = properties;
            this.label = label;
        }
        public string Label => label;
        public string Id => id;
        public string From => from;
        public string To => to;

        public string ToLabel {
            get
            {
                object nodeLabel;
                properties.TryGetValue("_toNode", out nodeLabel);
                return nodeLabel as string;
            }
        }

        public string SourceName
        {
            get
            {
                object nodeLabel;
                properties.TryGetValue(Node.SourceFieldName, out nodeLabel);
                return nodeLabel as string;
            }
        }

        public string FromLabel
        {
            get
            {
                object nodeLabel;
                properties.TryGetValue("_fromNode", out nodeLabel);
                return nodeLabel as string;
            }
        }
        
        public string FromKey
        {
            get
            {
                object toKey;
                properties.TryGetValue("_fromNodeKey", out toKey);
                return toKey as string;
            }
        }

        public string ToKey
        {
            get
            {
                object toKey;
                properties.TryGetValue("_toNodeKey", out toKey);
                return toKey as string;
            }
        }

        public string ToKeyValue
        {
            get
            {
                object toKey;
                properties.TryGetValue("_toNodeKeyValue", out toKey);
                return toKey as string;
            }
        }

        public IEnumerable<EdgeKey> Keys
        {
            get
            {
                bool found = this.Properties.TryGetValue(Node.KeyFieldName, out var valueObject);

                if (found)
                {
                    if (valueObject is string value)
                    {
                        var keyValues = value.Split(',');

                        foreach (var keyValue in keyValues)
                        {
                            var keyAndType = keyValue.Split(":");

                            if (keyAndType.Length > 1 && string.CompareOrdinal(keyAndType[1], "temporal") == 0)
                            {
                                yield return new EdgeKey(keyAndType[0], EdgeKeyTypeEnum.Temporal);
                            }
                            else
                            {
                                yield return new EdgeKey(keyAndType[0], EdgeKeyTypeEnum.StrictEqual);
                            }
                        }
                    }
                }
            }
        }

        public Dictionary<string, object> Attributes
        {
            get
            {
                return properties.Where(kv => !kv.Equals(Node.KeyFieldName)).ToDictionary(kv => kv.Key, kv => kv.Value);
            }
        }

        private IEnumerable<string> SpecialKeys
        {
            get
            {
                yield return Node.FromFieldName;
                yield return Node.HashFieldName;
                yield return Node.KeyFieldName;
                yield return Node.WriteTimeFieldName;
            }
        }

        public IDictionary<string, object> Properties
        {
            get
            {
                if (!properties.ContainsKey(Node.HashFieldName))
                {
                    properties.Add(Node.HashFieldName, Hash);
                }
                return properties;
            }
        }

        public string Hash
        {
            get
            {
                var concatValues = new StringBuilder();
                foreach (var keyValue in properties.ToList().OrderBy(k => k.Key))
                {
                    if (!SpecialKeys.Contains(keyValue.Key))
                    {
                        concatValues.Append(keyValue.Value);
                    }
                }
                //hash all the values to check for unicity
                return HashUtils.Sha1Hash(concatValues.ToString());
            }
        }

        public bool Equals(Edge other)
		{
			if (ReferenceEquals(null, other)) return false;
			if (ReferenceEquals(this, other)) return true;
			return string.Equals(id, other.id, StringComparison.OrdinalIgnoreCase)
					&& string.Equals(label, other.label, StringComparison.OrdinalIgnoreCase)
					&& string.Equals(@from, other.@from, StringComparison.OrdinalIgnoreCase)
					&& string.Equals(to, other.to, StringComparison.OrdinalIgnoreCase)
					&& DictionaryComparer.Equals(properties, other.properties);
		}

		public override bool Equals(object obj)
		{
			if (ReferenceEquals(null, obj)) return false;
			if (ReferenceEquals(this, obj)) return true;
			if (obj.GetType() != this.GetType()) return false;
			return Equals((Edge)obj);
		}

		public override int GetHashCode()
		{
			unchecked
			{
				var hashCode = (id != null ? StringComparer.OrdinalIgnoreCase.GetHashCode(id) : 0);
				hashCode = (hashCode * 397) ^ (label != null ? StringComparer.OrdinalIgnoreCase.GetHashCode(label) : 0);
				hashCode = (hashCode * 397) ^ (@from != null ? StringComparer.OrdinalIgnoreCase.GetHashCode(@from) : 0);
				hashCode = (hashCode * 397) ^ (to != null ? StringComparer.OrdinalIgnoreCase.GetHashCode(to) : 0);
				return hashCode;
			}
		}
	}
}
