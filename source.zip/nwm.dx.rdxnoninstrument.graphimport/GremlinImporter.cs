﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Gremlin.Net.Process.Traversal;
using Gremlin.Net.Structure;

namespace nwm.dx.rdxnoninstrument.graphimport
{
    public class GremlinImporter
    {
        public static int NbNodeTask = 4000;
        public static int NbEdgeTask = 4000;

        public event EventHandler<ErrorArgs> Error;
        public event EventHandler<EdgeArgs> EdgeImported;
        public event EventHandler<NodeArgs> NodeImported;

        private readonly IGraphReader graphReader;
        private readonly IImportStateManager importStateManager;
        private readonly bool syncCall = false;
        private readonly bool loadState = false;
        private GraphTraversalSource g;

        public GremlinImporter(
            GraphTraversalSource traversalSource,
            IGraphReader graphReader,
            IImportStateManager importStateManager,
            int nbNodeTask = 4000,
            int nbEdgeTask = 4000,
            bool syncCall = false,
            bool loadState = false)
        {
            this.g = traversalSource;
            this.graphReader = graphReader;
            NbNodeTask = nbNodeTask;
            NbEdgeTask = nbEdgeTask;
            this.syncCall = syncCall;
            this.loadState = loadState;
            this.importStateManager = importStateManager;
        }

        public long NodeProcessed => importStateManager.NodeProcessed;
        public long EdgeProcessed => importStateManager.EdgeProcessed;

        public void SaveState()
        {
            importStateManager.WriteStates();
        }

        public void Import()
        {
            var nodeTasks = new List<Tuple<Node, Task<object>>>();
            var edgeTasks = new List<Tuple<Edge, Task>>();

            if (loadState)
            {
                importStateManager.Load();
            }

            graphReader.NodeParsed += (sender, node) =>
            {
                try
                {
                    InsertionResult insertionResult = null;
                    if (syncCall)
                    {
                        insertionResult = InsertNode(g, node);
                    }
                    else
                    {
                        insertionResult = FireInsertNode(g, node, nodeTasks);
                        ProcessNodeTasks(nodeTasks);
                    }
                    OnNodeImported(new NodeArgs(node, insertionResult));
                }
                catch (Exception e)
                {
                    importStateManager.WriteStates();
                    OnError(new ErrorArgs("Node parsed", e));
                }

            };

            graphReader.EdgeParsed += (sender, edge) =>
            {
                try
                {
                    InsertionResult insertionResult = null;
                    if (syncCall)
                    {
                        insertionResult = InsertEdge(g, edge);
                    }
                    else
                    {
                        ProcessNodeTasks(nodeTasks, true);
                        insertionResult = FireInsertEdge(g, edge, edgeTasks);
                        ProcessEdgeTasks(edgeTasks);
                    }
                    OnEdgeImported(new EdgeArgs(edge, insertionResult));
                }
                catch (Exception e)
                {
                    importStateManager.WriteStates();
                    OnError(new ErrorArgs("Edge parsed", e));
                }
            };

            graphReader.Read();
            ProcessNodeTasks(nodeTasks, true);
            ProcessEdgeTasks(edgeTasks, true);
            importStateManager.WriteStates();
        }

        private InsertionResult InsertEdge(GraphTraversalSource g, Edge edge)
        {
            var sw = new Stopwatch();
            sw.Start();

            var internalFromId = importStateManager.GetInternalNodeId(edge.FromLabel, edge.From);
            if (internalFromId == 0)
            {
                InsertNode(g, new Node(edge.From, edge.FromLabel, null));
                internalFromId = importStateManager.GetInternalNodeId(edge.FromLabel, edge.From);
            }

            var internalToId = importStateManager.GetInternalNodeId(edge.ToLabel, edge.To);
            if (internalToId == 0)
            {
                var nodeProperties = new Dictionary<string, object>()
                {
                    {edge.ToKey, edge.ToKeyValue },
                    {Node.KeyFieldName, edge.ToKey },
                    {Node.LabelFieldName, edge.ToLabel }
                };

                if (edge.Properties.ContainsKey(Node.SourceFieldName))
                {
                    nodeProperties.Add(Node.SourceFieldName, edge.SourceName);
                }

                InsertNode(g, new Node(edge.To, edge.ToLabel, nodeProperties));
                internalToId = importStateManager.GetInternalNodeId(edge.ToLabel, edge.To);
            }


            var keys = edge.Keys.ToList();
            var queryBuilder = new StringBuilder();

            GraphTraversal<Gremlin.Net.Structure.Edge, Gremlin.Net.Structure.Edge> v = g.E().HasLabel(edge.Label);
            queryBuilder.Append($"g.E().hasLabel('{edge.Label}')");

            if (keys.Any())
            {
                foreach (var key in keys)
                {
                    switch (key.Type)
                    {
                        case EdgeKeyTypeEnum.StrictEqual:
                            {
                                v = v.Has(key.Value, edge.Properties[key.Value]);
                                queryBuilder.Append($" .has('{key.Value}', '{edge.Properties[key.Value]}')");
                                break;
                            }
                        case EdgeKeyTypeEnum.Temporal:
                            {
                                v = v.Has(key.Value, P.Lte(long.Parse(edge.Properties[key.Value].ToString()))).Order()
                                    .By(key.Value, Order.Decr).Limit<Gremlin.Net.Structure.Edge>(1);
                                queryBuilder.Append(
                                    $".has('{key.Value}', lte({edge.Properties[key.Value]})).order().by('{key.Value}', decr).limit(1)");
                                break;
                            }
                    }
                }
            }
            else
            {
                queryBuilder.Append(".limit(0)");
            }

            var addBuilder = new StringBuilder();
            var edgeTobeAdded = __.V(internalFromId).As("a").V(internalToId).As("b").AddE(edge.Label).From("a").To("b");
            addBuilder.Append($"__.V({internalFromId}).as('a').V({internalToId}).as('b').addE('{edge.Label}').from('a').to('b')");

            foreach (var property in edge.Attributes)
            {
                foreach (var value in property.Value.AsList())
                {
                    edgeTobeAdded = edgeTobeAdded.Property(property.Key, value);
                    addBuilder.Append($".property('{property.Key}', '{value}')");
                }
            }

            v = v.Fold().Coalesce<Gremlin.Net.Structure.Edge>(__.Unfold<Gremlin.Net.Structure.Edge>(), edgeTobeAdded);
            queryBuilder.Append($".fold().coalesce(unfold(), {addBuilder})");

            var id = v.Next().Id;
            queryBuilder.Append($".next().id()");
            importStateManager.AddEdgeProcessed(edge.Label, id.ToString());

            sw.Stop();
            return new InsertionResult((long)id, queryBuilder.ToString(), sw.ElapsedMilliseconds);
        }

        private InsertionResult FireInsertEdge(GraphTraversalSource g, Edge edge, List<Tuple<Edge, Task>> edgeTasks)
        {
            var sw = new Stopwatch();
            sw.Start();

            var internalFromId = importStateManager.GetInternalNodeId(edge.FromLabel, edge.From);
            if (internalFromId == 0)
            {
                InsertNode(g, new Node(edge.From, null, null));
                internalFromId = importStateManager.GetInternalNodeId(edge.FromLabel, edge.From);
            }

            var internalToId = importStateManager.GetInternalNodeId(edge.ToLabel, edge.To);
            if (internalToId == 0)
            {
                InsertNode(g, new Node(edge.To, null, null));
                internalToId = importStateManager.GetInternalNodeId(edge.ToLabel, edge.To);
            }

            var v = g.V(internalFromId).As("a").V(internalToId).As("b")
                .AddE(edge.Label)
                .From("a").To("b");

            var queryBuild = new StringBuilder();
            queryBuild.Append($"g.V({internalFromId}).as('a').V({internalToId}).as('b').addE('{edge.Label}').from('a').to('b')");

            foreach (var property in edge.Properties)
            {
                foreach (var value in property.Value.AsList())
                {
                    v = v.Property(property.Key, value);
                    queryBuild.Append($".property('{property.Key}', '{value}')");
                }
            }

            Task promise = v.Promise(t => t.Next());
            edgeTasks.Add(new Tuple<Edge, Task>(edge, promise));
            sw.Stop();
            return new InsertionResult(0, queryBuild.ToString(), sw.ElapsedMilliseconds);
        }

        private InsertionResult InsertNode(GraphTraversalSource g, Node node)
        {
            var sw = new Stopwatch();
            sw.Start();

            var queryBuild = new StringBuilder();
            queryBuild.Append("g.V()");
            var v = g.V();

            List<string> keys = node.Keys.ToList();

            if (keys.Any())
            {
                foreach (var key in keys)
                {
                    v = v.Has(key, node.Attributes[key]);

                    queryBuild.Append($".has('{key}', '{node.Attributes[key]}')");
                }

                queryBuild.Append($".hasLabel('{node.Label}').limit(1)");
                v = v.HasLabel(node.Label).Limit<Vertex>(1);

                var addBuilder = new StringBuilder($"__.addV('{node.Label}')");

                var nodetoAdd = __.AddV(node.Label);

                foreach (var property in node.Attributes)
                {
                    foreach (var value in property.Value.AsList())
                    {
                        nodetoAdd = nodetoAdd.Property(property.Key, value);
                        addBuilder.Append($".property('{property.Key}', '{value}')");
                    }
                }

                var unfold = __.Unfold<Vertex>();
                var altKeysBuilder = new StringBuilder();
                foreach (var value in node.AltKeys)
                {
                    unfold = unfold.Property(Node.AltKeyFieldName, value);
                    altKeysBuilder.Append($".property('{Node.AltKeyFieldName}', '{value}')");
                }

                queryBuild.Append($".fold().coalesce(unfold(){altKeysBuilder}, {addBuilder})");
                v = v.Fold().Coalesce<Vertex>(unfold, nodetoAdd);
            }
            else
            {
                v = (node.Label == null) ? g.AddV() : g.AddV(node.Label);

                foreach (var property in node.Attributes)
                {
                    foreach (var value in property.Value.AsList())
                    {
                        v = v.Property(property.Key, value);
                    }
                }
            }

            object internalNodeObject = v.Id().Next();
            queryBuild.Append(".id()");

            if (internalNodeObject != null)
            {
                importStateManager.AddNodeProcessed(node.Label, node.Id, (long)internalNodeObject);
            }
            else
            {
                OnError(new ErrorArgs($"Node id {node.Id} has not been created", null));
            }
            sw.Stop();
            return new InsertionResult((long?)internalNodeObject ?? 0, queryBuild.ToString(), sw.ElapsedMilliseconds);
        }

        private InsertionResult FireInsertNode(GraphTraversalSource g, Node node, List<Tuple<Node, Task<object>>> nodeTasks)
        {
            var sw = new Stopwatch();
            sw.Start();

            var internalNodeId = importStateManager.GetInternalNodeId(node.Label, node.Id);

            var queryBuild = new StringBuilder();
            queryBuild.Append($"g.V({internalNodeId})");
            var exists = g.V(internalNodeId).Next();

            var v = (exists == null) ? g.AddV(node.Label) : g.V(internalNodeId);

            queryBuild.Append(exists == null ? $"g.AddV({node.Label})" : $"g.AddV({internalNodeId})");

            foreach (var property in node.Properties)
            {
                foreach (var value in property.Value.AsList())
                {
                    v = v.Property(property.Key, value);
                    queryBuild.Append($".property('{property.Key}', '{value}')");
                }
            }

            var promise = v.Id().Promise(t => t.Next());
            queryBuild.Append($".id()");
            nodeTasks.Add(new Tuple<Node, Task<object>>(node, promise));

            sw.Stop();
            return new InsertionResult(0, queryBuild.ToString(), sw.ElapsedMilliseconds);
        }

        private void ProcessEdgeTasks(List<Tuple<Edge, Task>> edgeTasks, bool forceProcess = false)
        {
            if (edgeTasks.Count() > NbEdgeTask || forceProcess)
            {
                foreach (var edgeTask in edgeTasks)
                {
                    try
                    {
                        edgeTask.Item2.GetAwaiter().GetResult();
                        edgeTask.Item2.Dispose();
                        importStateManager.AddEdgeProcessed(edgeTask.Item1.Label, edgeTask.Item1.Id);
                    }
                    catch (Exception ex)
                    {
                        importStateManager.AddEdgeFailed(edgeTask.Item1.Label, edgeTask.Item1.Id);
                        OnError(new ErrorArgs("failed inserting edge", ex));
                        importStateManager.WriteEdgeFailed();
                    }
                }
                edgeTasks.Clear();
            }
        }

        private void ProcessNodeTasks(List<Tuple<Node, Task<object>>> nodeTasks, bool forceProcess = false)
        {
            if (nodeTasks.Count() > NbNodeTask || forceProcess)
            {
                foreach (var nodeTask in nodeTasks)
                {
                    try
                    {
                        var backendId = (long)nodeTask.Item2.GetAwaiter().GetResult();
                        nodeTask.Item2.Dispose();
                        importStateManager.AddNodeProcessed(nodeTask.Item1.Label, nodeTask.Item1.Id, backendId);

                    }
                    catch (Exception e)
                    {
                        OnError(new ErrorArgs($"node failled {nodeTask.Item1}", e));
                        throw;
                    }
                }
                nodeTasks.Clear();
            }
        }

        private void OnError(ErrorArgs errorArgs)
        {
            Error?.Invoke(this, errorArgs);
        }

        protected virtual void OnEdgeImported(EdgeArgs e)
        {
            EdgeImported?.Invoke(this, e);
        }

        protected virtual void OnNodeImported(NodeArgs e)
        {
            NodeImported?.Invoke(this, e);
        }
    }
}
