﻿using System;

namespace nwm.dx.rdxnoninstrument.graphimport
{
    public interface IGraphReader
    {
        event EventHandler<Node> NodeParsed;
        event EventHandler<Edge> EdgeParsed;
        void Read();
    }
}
