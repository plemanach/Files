﻿using System;

namespace nwm.dx.rdxnoninstrument.graphimport.Exceptions
{
    public class GraphImportTimeoutException : Exception
    {
        public GraphImportTimeoutException(string message) : base(message)
        {

        }

        public GraphImportTimeoutException(string message, Exception ex) : base(message, ex)
        {

        }
    }
}
