﻿using System;

namespace nwm.dx.rdxnoninstrument.graphimport
{
    public class NodeArgs : EventArgs
    {
        public InsertionResult insertionResult;
        public Node node;

        public NodeArgs(Node node, InsertionResult insertionResult)
        {
            this.node = node;
            this.insertionResult = insertionResult;
        }
    }
}
