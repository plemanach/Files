﻿using System;
using System.IO;
using System.Xml;

namespace nwm.dx.rdxnoninstrument.graphimport
{
    public sealed class GraphMLWriter : IDisposable
    {
        private readonly GraphObject graphObject;
        private readonly XmlTextWriter xmlTextWriter;

		public GraphMLWriter(GraphObject graphObject, string filepath): this(graphObject, new StreamWriter(filepath))
        {
        }

        public GraphMLWriter(GraphObject graphObject, StreamWriter streamWriter)
        {
            this.graphObject = graphObject;
            xmlTextWriter = new XmlTextWriter(streamWriter);
        }

        public void Write()
        {
            xmlTextWriter.WriteStartElement("graphml");
            foreach (var node in graphObject.Nodes)
            {
                WriteNode(node);
            }

            foreach (var edge in graphObject.Edges)
            {
                WriteEdge(edge);
            }
            xmlTextWriter.WriteEndElement();
            xmlTextWriter.Flush();
        }

        private void WriteEdge(Edge edge)
        {
            xmlTextWriter.WriteStartElement("edge");
            xmlTextWriter.WriteAttributeString("id", edge.Id);
            xmlTextWriter.WriteAttributeString("source", edge.From);
            xmlTextWriter.WriteAttributeString("target", edge.To);

            foreach (var property in edge.Properties)
            {
                AddProperty(property.Key, property.Value);
            }

            AddProperty("labelE", edge.Label);
            xmlTextWriter.WriteEndElement();
        }

        private void WriteNode(Node node)
        {
            xmlTextWriter.WriteStartElement("node");
            xmlTextWriter.WriteAttributeString("id", node.Id);

            foreach (var property in node.Properties)
            {
                AddProperty(property.Key, property.Value);
            }

            AddProperty("labelV", node.Label);
            xmlTextWriter.WriteEndElement();
        }

        private void AddProperty(string key, object value)
        {
            foreach (var v in value.AsList())
            {
	            xmlTextWriter.WriteStartElement("data");
	            xmlTextWriter.WriteAttributeString("key", key);

                if (v != null && v.GetType().IsEnum)
	            {
		            xmlTextWriter.WriteValue((int) v);
	            }
	            else
	            {
		            xmlTextWriter.WriteValue(v);
	            }

                xmlTextWriter.WriteEndElement();
            }
        }

        public void Dispose()
        {
            xmlTextWriter?.Dispose();
        }
    }
}
