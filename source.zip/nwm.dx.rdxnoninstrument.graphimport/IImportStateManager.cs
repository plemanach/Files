﻿using System;

namespace nwm.dx.rdxnoninstrument.graphimport
{
    public interface IImportStateManager
    {
        long NodeProcessed { get; }
        long EdgeProcessed { get; }
        void AddEdgeProcessed(string label, string id);
        void AddNodeProcessed(string label, string id, long janusNodeId);
        long GetInternalNodeId(string label, string id);
        void AddEdgeFailed(string label, string id);
        void Load();
        void WriteEdgeFailed();
        void LoadNodeState();
        void LoadEdgeState();
        void WriteState();
        void WriteStateEdge();
        void WriteStates();
    }
}