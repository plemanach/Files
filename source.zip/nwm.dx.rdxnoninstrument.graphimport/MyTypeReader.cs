﻿using Gremlin.Net.Structure.IO.GraphSON;
using Newtonsoft.Json.Linq;

namespace nwm.dx.rdxnoninstrument.graphimport
{
    internal class MyTypeReader : IGraphSONDeserializer
    {
        public dynamic Objectify(JToken graphsonObject, GraphSONReader reader)
        {
            return new RelationIdentifier();
        }
    }
}

