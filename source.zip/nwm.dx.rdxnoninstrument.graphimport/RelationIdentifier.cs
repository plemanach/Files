﻿using System;
using System.Collections.Generic;
using System.Text;
using Gremlin.Net.Structure.IO.GraphSON;

namespace nwm.dx.rdxnoninstrument.graphimport
{
    public class RelationIdentifier
    {
        public static string GraphsonPrefix = "janusgraph";
        public static string GraphsonBaseType = "RelationIdentifier";
        public static string GraphsonType = GraphSONUtil.FormatTypeName(GraphsonPrefix, GraphsonBaseType);
    }
}
