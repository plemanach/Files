﻿using System;

namespace nwm.dx.rdxnoninstrument.graphimport
{
    public class EdgeArgs: EventArgs
    {
        public InsertionResult insertionResult;
        public Edge edge;

        public EdgeArgs(Edge edge, InsertionResult insertionResult)
        {
            this.edge = edge;
            this.insertionResult = insertionResult;
        }
    }
}
