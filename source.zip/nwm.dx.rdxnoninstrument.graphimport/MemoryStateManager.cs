﻿using System.Collections.Generic;
using nwm.dx.utils;

namespace nwm.dx.rdxnoninstrument.graphimport
{
    public class MemoryStateManager : IImportStateManager
    {
        private readonly Dictionary<KeyValuePair<string, string>, long> internalNodeIds = new Dictionary<KeyValuePair<string, string>, long>();
        private readonly HashSet<KeyValuePair<string, string>> edgeProcessed = new HashSet<KeyValuePair<string, string>>();
        private readonly HashSet<KeyValuePair<string, string>> edgeFailed = new HashSet<KeyValuePair<string, string>>();

        public long NodeProcessed => internalNodeIds.Count;
        public long EdgeProcessed => edgeProcessed.Count;

        public void AddEdgeProcessed(string label, string id)
        {
            ArgumentValidator.CheckForNullOrEmptyString(label, nameof(label));
            ArgumentValidator.CheckForNullOrEmptyString(id, nameof(id));

            edgeProcessed.Add(new KeyValuePair<string, string>(label, id));
        }

        public void AddNodeProcessed(string label, string id, long janusNodeId)
        {
            ArgumentValidator.CheckForNullOrEmptyString(label, nameof(label));
            ArgumentValidator.CheckForNullOrEmptyString(id, nameof(id));

            var kvp = new KeyValuePair<string, string>(label, id);
            if (!internalNodeIds.ContainsKey(kvp))
            {
                internalNodeIds.Add(kvp, janusNodeId);
            }
        }

        public long GetInternalNodeId(string label, string id)
        {
            ArgumentValidator.CheckForNullOrEmptyString(label, nameof(label));
            ArgumentValidator.CheckForNullOrEmptyString(id, nameof(id));

            long internalNodeId = 0;

            if (id != null)
            {
                var kvp = new KeyValuePair<string, string>(label, id);
                internalNodeIds.TryGetValue(kvp, out internalNodeId);
            }

            return internalNodeId;
        }

        public void AddEdgeFailed(string label, string id)
        {
            ArgumentValidator.CheckForNullOrEmptyString(label, nameof(label));
            ArgumentValidator.CheckForNullOrEmptyString(id, nameof(id));

            edgeFailed.Add(new KeyValuePair<string, string>(label, id));
        }
        
        public void Load()
        {
            
        }

        public void WriteEdgeFailed()
        {
            
        }

        public void LoadNodeState()
        {
            
        }

        public void LoadEdgeState()
        {
           
        }

        public void WriteState()
        {
           
        }

        public void WriteStateEdge()
        {
           
        }

        public void WriteStates()
        {
           
        }
    }
}
