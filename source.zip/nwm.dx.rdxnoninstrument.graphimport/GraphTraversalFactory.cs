﻿using System;
using System.Collections.Generic;
using Gremlin.Net.Driver;
using Gremlin.Net.Driver.Remote;
using Gremlin.Net.Process.Traversal;
using Gremlin.Net.Structure;
using Gremlin.Net.Structure.IO.GraphSON;

namespace nwm.dx.rdxnoninstrument.graphimport
{
    public static class GraphTraversalFactory
    {
        public static GraphTraversalSource CreateTraversal(string host, int port)
        {
            var graphsonReader =
                new GraphSON3Reader(new Dictionary<string, IGraphSONDeserializer>
                {
                    {RelationIdentifier.GraphsonType, new MyTypeReader()}
                });
            var graphsonWriter = new GraphSON3Writer();
            var graph = new Graph();

            return graph.Traversal().WithRemote(new DriverRemoteConnection(new GremlinClient(
                new GremlinServer(host, port, false), graphsonReader, graphsonWriter, GremlinClient.DefaultMimeType)));
        }
    }
}
