﻿using System;
using System.Diagnostics;

namespace nwm.dx.rdxnoninstrument.graphimport
{
    class Program
    {
        static void Main(string[] args)
        {
            int nbNodeTask = GremlinImporter.NbNodeTask;
            int nbEdgeTask = GremlinImporter.NbEdgeTask;
            if (args.Length < 3)
            {
                Console.WriteLine(
                    "usage GremlinImport.exe {filepath} {host} {port} {NbNodeTaskInFly} {NbEdgeTaskInFly}");
            }

            if (args.Length >= 4)
            {
                int NbNodeTaskInFly;
                nbNodeTask = int.TryParse(args[3], out NbNodeTaskInFly) ? NbNodeTaskInFly : nbNodeTask;
            }

            if (args.Length >= 5)
            {
                int NbEdgeTaskInFly;
                nbEdgeTask = int.TryParse(args[4], out NbEdgeTaskInFly) ? NbEdgeTaskInFly : nbEdgeTask;
            }

            Stopwatch watch = new Stopwatch();
            watch.Start();
            Import(args[0], args[1], int.Parse(args[2]), nbNodeTask, nbEdgeTask);
            watch.Stop();
            Console.WriteLine($"time: {watch.Elapsed.TotalSeconds}");
            Console.ReadLine();
        }

        static void Import(string uri, string host, int port, int nbNodeTask, int nbEdgeTask)
        {
            var graphmlReader = new GraphMLReader(uri);
            var gremlinImport = new GremlinImporter(
                GraphTraversalFactory.CreateTraversal(host, port), 
                graphmlReader, 
                new ImportStateManager(), nbNodeTask,  nbEdgeTask);

            gremlinImport.Import();

            Console.CancelKeyPress += (s, args) =>
            {
                Console.WriteLine("Control c press");
                gremlinImport.SaveState();
            };

            Console.WriteLine($"count: {gremlinImport.NodeProcessed}, {gremlinImport.EdgeProcessed}");
            Console.WriteLine($"finished");
        }
    }
}
